#ifndef HEADER_H
#define HEADER_H

int Add(int x, int y);

#endif // HEADER_H
